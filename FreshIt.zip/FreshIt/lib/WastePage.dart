import 'package:flutter/material.dart';

class WastePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('This is Waste Page'),
    );
  }

}