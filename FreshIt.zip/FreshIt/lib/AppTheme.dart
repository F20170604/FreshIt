import 'package:flutter/material.dart';

class AppTheme {
  static Color primaryColor = Color.fromRGBO(23, 69, 145, 1.0);
  static String primaryFont = "Flama";
}
